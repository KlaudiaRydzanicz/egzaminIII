export interface City {
  id: string;
  location: string;
  name: string;
  description: string;
  url: string;
}
